

function App() {
  return (
    <div className="text-4xl underline font-extrabold m-2 p-3 bg-green-500">
      Hello World
    </div>
  );
}

export default App;
