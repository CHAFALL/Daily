package com.d212.taiso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaisoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaisoApplication.class, args);
	}

}
