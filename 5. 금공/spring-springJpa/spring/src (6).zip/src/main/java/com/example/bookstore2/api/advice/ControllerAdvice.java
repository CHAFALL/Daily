package com.example.bookstore2.api.advice;

import com.example.bookstore2.api.response.ApiErrorResponse;
import com.example.bookstore2.exception.BusinessLogicException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ControllerAdvice {

    @ExceptionHandler(BusinessLogicException.class)
    public ApiErrorResponse handleIllegalArgumentException(BusinessLogicException e){
        return ApiErrorResponse.fail(e.getErrorCode(), e.getMessage());
    }
}
