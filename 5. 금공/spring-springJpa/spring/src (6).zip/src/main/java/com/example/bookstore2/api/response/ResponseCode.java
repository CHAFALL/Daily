package com.example.bookstore2.api.response;

import lombok.Getter;

@Getter
public enum ResponseCode {
    OK(200000), CREATED(201000);

    private int code;

    ResponseCode(int i) {}
}
