package com.example.bookstore2.api.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ErrorCode {
    // xxx xxx
    BAD_REQUEST(400000, "Bad Request"),
    NOT_FOUND_MEMBER(404001, "Not Found Member");

    private int code;
    private String message;
}
