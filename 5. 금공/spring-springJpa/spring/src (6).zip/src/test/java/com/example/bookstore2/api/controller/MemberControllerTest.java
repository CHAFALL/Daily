package com.example.bookstore2.api.controller;

import com.example.bookstore2.api.request.MemberRequest;
import com.example.bookstore2.domain.model.Member;
import com.example.bookstore2.service.MemberService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest
class MemberControllerTest {
    @MockBean
    private MemberService memberService;
    private ObjectMapper om = new ObjectMapper();
    @Autowired
    private MockMvc mockMvc;

    @Test
    void createMember() throws Exception {
        // given
        given(memberService.registerMember(anyString(), anyInt()))
                .willReturn(
                        new Member("kim", 20)
                );

        MemberRequest.Create reqObj = MemberRequest.Create.builder()
                .name("test")
                .age(10)
                .build();

        String reqBody = om.writeValueAsString(reqObj);

        // when // then
        mockMvc.perform(
                post("/members")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(reqBody)
        )
                .andDo(print())
                .andExpect(jsonPath("$.name").isString())
                .andExpect(jsonPath("$.age").value(20));

    }

}