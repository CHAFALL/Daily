package com.example.bookstore2.service;

import com.example.bookstore2.domain.model.Member;
import com.example.bookstore2.domain.repository.MemberRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class MemberServiceTest {
    @Autowired
    private MemberService memberService;
    @Autowired
    private MemberRepository memberRepository;

    @Test
    void registerMember(){
        // given
        // when
        Member member = memberService.registerMember("kim", 20);

        // then
        Member foundMember = memberRepository.findById(member.getId())
                .orElseThrow();

        Assertions.assertThat(member.getId()).isEqualTo(foundMember.getId());
        Assertions.assertThat(member.getName()).isEqualTo(foundMember.getName());
    }

    void findOne(){
//        memberService.findOneMember()
    }
}