package com.example.dormitory2.domain.repository;

import com.example.dormitory2.domain.model.Book;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookMapRepository implements BookRepository {
    private static Long LAST_ID = 1L;

    private Map<Long, Book> storage = new HashMap<>();

    @Override
    public Book save(Book book) {
        Long newId = LAST_ID;
        LAST_ID = LAST_ID + 1;

        book.setId(newId);

        storage.put(newId, book);

        return book;
    }

    @Override
    public List<Book> findAll() {
        return storage.values().stream().toList();
    }

    @Override
    public Book findById(Long id) {
        return storage.get(id);
    }
}
