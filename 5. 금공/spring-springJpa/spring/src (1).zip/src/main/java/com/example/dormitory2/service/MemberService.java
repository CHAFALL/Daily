package com.example.dormitory2.service;

import com.example.dormitory2.domain.model.Member;
import com.example.dormitory2.domain.repository.MemberListRepository;
import com.example.dormitory2.domain.repository.MemberMapRepository;
import com.example.dormitory2.domain.repository.MemberRepository;

import java.util.List;

public class MemberService {
    private MemberRepository memberRepository;

    public MemberService(MemberRepository memberRepository){
        this.memberRepository = memberRepository;
    }

    public Member registerMember(String name, int grade){
        // 1. 받은 정보로 Member 객체를 생성한다.
        Member member = new Member(name, grade);

        // 2. Member 객체를 저장한다.
        return memberRepository.save(member);
    }

    public List<Member> findAllMember(){
        return memberRepository.findAll();
    }
}
