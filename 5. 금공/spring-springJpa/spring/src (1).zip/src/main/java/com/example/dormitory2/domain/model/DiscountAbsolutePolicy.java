package com.example.dormitory2.domain.model;

public class DiscountAbsolutePolicy implements DiscountPolicy {
    @Override
    public int calculate(int price) {
        return price-1000;
    }
}
