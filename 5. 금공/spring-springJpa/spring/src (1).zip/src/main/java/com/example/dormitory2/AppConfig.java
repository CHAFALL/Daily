package com.example.dormitory2;

import com.example.dormitory2.domain.model.DiscountAbsolutePolicy;
import com.example.dormitory2.domain.model.DiscountPolicy;
import com.example.dormitory2.domain.repository.BookMapRepository;
import com.example.dormitory2.domain.repository.BookRepository;
import com.example.dormitory2.domain.repository.MemberMapRepository;
import com.example.dormitory2.domain.repository.MemberRepository;
import com.example.dormitory2.service.BookService;
import com.example.dormitory2.service.MemberService;

public class AppConfig {

    public MemberRepository memberRepository() {
        return new MemberMapRepository();
    }

    public BookRepository bookRepository() {
        return new BookMapRepository();
    }

    public DiscountPolicy discountPolicy() {
        return new DiscountAbsolutePolicy();
    }

    public MemberService memberService() {
        return new MemberService(memberRepository());
    }

    public BookService bookService() {
        return new BookService(
                memberRepository(),
                bookRepository(),
                discountPolicy()
        );
    }
}
