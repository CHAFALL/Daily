package com.example.dormitory2.domain.model;

public class DiscountPercentPolicy implements DiscountPolicy {
    @Override
    public int calculate(int price){
        return (int)(price * 0.5);
    }
}
