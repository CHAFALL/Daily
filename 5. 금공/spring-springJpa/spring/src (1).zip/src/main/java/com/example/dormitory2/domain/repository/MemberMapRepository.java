package com.example.dormitory2.domain.repository;

import com.example.dormitory2.domain.model.Member;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MemberMapRepository implements MemberRepository {
    private static Long LAST_ID = 1L;

    private Map<Long, Member> storage = new HashMap<>();

    public Member save(Member member){
        // 1. id 값을 생성
        Long newId = LAST_ID;
        LAST_ID = LAST_ID+1;

        // 2. id를 Member에 저장
        member.setId(newId);

        // 3. member를 영속화 한다.
        storage.put(newId, member);

        // 4. member return
        return member;
    }

    public List<Member> findAll(){
        return storage.values().stream().toList();
    }

    public Member findById(Long id){
        return storage.get(id);
    }

}
