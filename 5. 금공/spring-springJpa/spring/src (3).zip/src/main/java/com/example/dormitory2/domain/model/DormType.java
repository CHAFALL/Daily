package com.example.dormitory2.domain.model;

public enum DormType {
    OREUM, PREUM;
}
