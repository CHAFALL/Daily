package com.example.dormitory2;

import com.example.dormitory2.domain.model.DiscountPercentPolicy;
import com.example.dormitory2.domain.model.DiscountPolicy;
import com.example.dormitory2.domain.repository.BookMapRepository;
import com.example.dormitory2.domain.repository.BookRepository;
import com.example.dormitory2.domain.repository.MemberMapRepository;
import com.example.dormitory2.domain.repository.MemberRepository;
import com.example.dormitory2.service.BookService;
import com.example.dormitory2.service.MemberService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringAppConfig {
    @Bean
    public MemberRepository memberRepository(){
        return new MemberMapRepository();
    }

    @Bean
    public BookRepository bookRepository(){
        return new BookMapRepository();
    }

    @Bean
    public DiscountPolicy discountPolicy(){
        return new DiscountPercentPolicy();
    }

    @Bean
    public MemberService memberService(){
        return new MemberService(memberRepository());
    }

    @Bean
    public BookService bookService(){
        return new BookService(memberRepository(), bookRepository(), discountPolicy());
    }


}