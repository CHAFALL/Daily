package com.example.dormitory2.domain.model;

public interface DiscountPolicy {
    int calculate(int price);
}
