package com.example.dormitory2;

import com.example.dormitory2.domain.model.DiscountAbsolutePolicy;
import com.example.dormitory2.domain.model.DormType;
import com.example.dormitory2.domain.model.Member;
import com.example.dormitory2.domain.repository.*;
import com.example.dormitory2.service.BookService;
import com.example.dormitory2.service.MemberService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;

public class Main {
    public static void main(String[] args) {
//        AppConfig appConfig = new AppConfig();

        ApplicationContext ac = new AnnotationConfigApplicationContext(SpringAppConfig.class);

        MemberService memberService = ac.getBean("memberService", MemberService.class);
        Member member = memberService.registerMember("kim", 1);

        BookService bookService = ac.getBean("bookService", BookService.class);
        bookService.bookDormitory(member.getId(), DormType.PREUM);

        bookService.findAllBook().stream()
                .forEach(b -> System.out.println("b = " + b.getMember()));
    }
}
