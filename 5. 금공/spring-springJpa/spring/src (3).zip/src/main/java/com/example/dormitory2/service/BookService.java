package com.example.dormitory2.service;

import com.example.dormitory2.domain.model.*;
import com.example.dormitory2.domain.repository.BookMapRepository;
import com.example.dormitory2.domain.repository.BookRepository;
import com.example.dormitory2.domain.repository.MemberMapRepository;
import com.example.dormitory2.domain.repository.MemberRepository;

import java.util.List;

public class BookService {
    private MemberRepository memberRepository;
    private BookRepository bookRepository;
    private DiscountPolicy discountPolicy;

    public BookService(
            MemberRepository memberRepository,
            BookRepository bookRepository,
            DiscountPolicy discountPolicy
    ){
        this.memberRepository = memberRepository;
        this.bookRepository = bookRepository;
        this.discountPolicy = discountPolicy;
    }

    // 1. 생활관 신청할 Member ID와 기숙사 타입을 인자로 받는다.
    public void bookDormitory(Long memberId, DormType type){
        // 이영역의 코드는 변경하지 말기 ==================

        // 2. 가격을 계산한다.
        // 가격 계산 정책이 두개 있음.
        // 1. 가격의 50%로 할인
        // 2. 가격의 -1000을 하는 할인

        int price = 0;
        if(type==DormType.OREUM){
            price = 5000;
        }else if(type==DormType.PREUM){
            price = 3000;
        }

        price = discountPolicy.calculate(price);

        // 3. Book 객체를 생성한다.
        // 3.1 member 객체, price, DormType
        Member member = memberRepository.findById(memberId);
        Book book = new Book(member, price, type);

        // 4. Book 객체를 저장한다.
        bookRepository.save(book);

        // 이 영역의 코드는 변경하지 말기 ====================
    }

    public List<Book> findAllBook(){
        return bookRepository.findAll();
    }

}
