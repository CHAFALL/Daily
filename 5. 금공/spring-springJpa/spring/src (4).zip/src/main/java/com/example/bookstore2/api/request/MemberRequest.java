package com.example.bookstore2.api.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public class MemberRequest {
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Create{
        private String name;
        private Integer age;
    }
}
