package com.example.bookstore2.api.controller;

import com.example.bookstore2.api.request.MemberRequest;
import com.example.bookstore2.api.response.MemberResponse;
import com.example.bookstore2.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequiredArgsConstructor
public class MemberController {
    private final MemberService memberService;

    @PostMapping("/members")
    @ResponseBody
    public MemberResponse.Detail registerMember(@RequestBody MemberRequest.Create request){
        return MemberResponse.Detail.of(memberService.registerMember(request.getName(), request.getAge()));
    }

}
