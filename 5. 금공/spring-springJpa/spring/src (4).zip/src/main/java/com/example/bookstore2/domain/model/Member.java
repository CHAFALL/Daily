package com.example.bookstore2.domain.model;

import lombok.Getter;
import lombok.Setter;

@Getter
public class Member {
    @Setter
    private Long id;
    private String name;
    private Integer age;

    public Member(String name, Integer age) {
        this.name = name;
        this.age = age;
    }
}
