package com.example.bookstore2.domain.repository;

import com.example.bookstore2.domain.model.Member;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class MemberRepository {
    private static Long LAST_ID = 1L;

    private Map<Long, Member> storage = new HashMap<>();


    public Member save(Member member){
        Long newId = LAST_ID;
        LAST_ID++; // LAST_ID = LAST_ID + 1;

        member.setId(newId);

        storage.put(newId, member);

        return member;
    }

    public List<Member> findAll(){
        return new ArrayList<>(storage.values());
    }

    public Optional<Member> findById(Long id){
        return Optional.ofNullable(storage.get(id));
    }
}
