package com.example.dormitory2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dormitory2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
