package com.example.dormitory2.domain.model;

public class Member {
    private Long id;
    private String name;
    private Integer grade;

    public Member(String name, int grade) {
        this.name = name;
        this.grade = grade;
    }

    public void setId(Long newId) {
        this.id = newId;
    }

    public String getName(){
        return this.name;
    }

    public Long getId(){
        return id;
    }
}
