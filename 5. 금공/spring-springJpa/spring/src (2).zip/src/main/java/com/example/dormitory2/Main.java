package com.example.dormitory2;

import com.example.dormitory2.domain.model.DiscountAbsolutePolicy;
import com.example.dormitory2.domain.model.DormType;
import com.example.dormitory2.domain.model.Member;
import com.example.dormitory2.domain.repository.*;
import com.example.dormitory2.service.BookService;
import com.example.dormitory2.service.MemberService;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        AppConfig appConfig = new AppConfig();

        MemberService memberService = appConfig.memberService();
        Member member = memberService.registerMember("kim", 1);

        BookService bookService = appConfig.bookService();
        bookService.bookDormitory(member.getId(), DormType.PREUM);

        bookService.findAllBook().stream()
                .forEach(b -> System.out.println("b = " + b.getMember()));
    }
}
