package com.example.dormitory2.domain.repository;

import com.example.dormitory2.domain.model.Member;

import java.util.List;

public interface MemberRepository {
    Member save(Member member);
    List<Member> findAll();
    Member findById(Long id);
}
