package com.example.dormitory2;

import com.example.dormitory2.domain.model.DiscountAbsolutePolicy;
import com.example.dormitory2.domain.model.DiscountPolicy;
import com.example.dormitory2.domain.repository.*;
import com.example.dormitory2.service.BookService;
import com.example.dormitory2.service.MemberService;

public class AppConfig {
    private MemberRepository memberRepository;
    private BookRepository bookRepository;
    private DiscountPolicy discountPolicy;
    private MemberService memberService;
    private BookService bookService;

    public MemberRepository memberRepository() {
        if(memberRepository==null){
            memberRepository = new MemberMapRepository();
        }

        return memberRepository;
    }

    public BookRepository bookRepository() {
        if(bookRepository==null){
            bookRepository = new BookMapRepository();
        }

        return new BookMapRepository();
    }

    public DiscountPolicy discountPolicy() {
        if(discountPolicy==null){
            discountPolicy = new DiscountAbsolutePolicy();
        }

        return new DiscountAbsolutePolicy();
    }

    public MemberService memberService() {
        if(memberService==null){
            memberService = new MemberService(memberRepository());
        }

        return new MemberService(memberRepository());
    }

    public BookService bookService() {
        if(bookService==null){
            bookService = new BookService(memberRepository(), bookRepository(), discountPolicy());
        }

        return bookService;
    }
}
