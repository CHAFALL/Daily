package com.example.bookstore2.api.controller;

import com.example.bookstore2.api.request.MemberRequest;
import com.example.bookstore2.api.response.MemberResponse;
import com.example.bookstore2.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RequestMapping("/members")
@RestController
@Slf4j
public class MemberController {
    private final MemberService memberService;

//    @PostMapping("/members")
    // RestfulAPI(==HTTP API) vs RestAPI
    // => 데이터를 주고 받을 때 사용하는 API
    @PostMapping
    public MemberResponse.Detail registerMember(@RequestBody MemberRequest.Create request){
        return MemberResponse.Detail.of(memberService.registerMember(request.getName(), request.getAge()));
    }

    // 1번 멤버 호출 /members/1
    //  2번 멤버 호출 /members/2
//    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @GetMapping("/{id}")
    public MemberResponse.Detail findMemberOne(@PathVariable(name = "id") Long memberId){
        return MemberResponse.Detail.of(memberService.findOneMember(memberId));
    }
}
