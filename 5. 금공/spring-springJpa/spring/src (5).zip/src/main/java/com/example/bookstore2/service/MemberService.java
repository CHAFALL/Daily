package com.example.bookstore2.service;

import com.example.bookstore2.domain.model.Member;
import com.example.bookstore2.domain.repository.MemberRepository;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MemberService {
    private final MemberRepository memberRepository;

    public Member registerMember(String name, int age){
        Member member = new Member(name, age);

        return memberRepository.save(member);
    }

    public Member findOneMember(Long id){
        return memberRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당하는 멤버가 없습니다."));
    }
}
