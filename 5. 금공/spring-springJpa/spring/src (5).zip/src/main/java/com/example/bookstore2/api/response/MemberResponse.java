package com.example.bookstore2.api.response;

import com.example.bookstore2.domain.model.Member;
import lombok.Builder;
import lombok.Data;

public class MemberResponse {
    @Data
    @Builder
    public static class Detail{
        private Long id;
        private String name;
        private Integer age;

        public static MemberResponse.Detail of(Member member){
            return Detail.builder()
                    .id(member.getId())
                    .name(member.getName())
                    .age(member.getAge())
                    .build();
        }
    }
}
