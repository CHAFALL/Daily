package com.example.bookstore2.domain.model;

import com.example.bookstore2.domain.repository.MemberRepository;
import com.example.bookstore2.service.MemberService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.*;


class MemberTest {
    @BeforeAll
    public static void beforeAll(){
        System.out.println("======before All====");
    }

    @AfterAll
    public static void AfterAll(){
        System.out.println("======after All====");
    }

    @Test
    @DisplayName("Member 생성")
    public void createTest(){
        Member member = new Member("test", 1);
        member.setId(1L);

        Member member2 = new Member("test2",2);
        member2.setId(1L);

        Assertions.assertThat(member).isEqualTo(member2);
        Assertions.assertThat(member.getAge()).isEqualTo(1);
    }


    @DisplayName("예외 테스트")
    @Test
    void exception_test(){
        //given
        MemberRepository memberRepository = new MemberRepository();
        MemberService memberService = new MemberService(memberRepository);
        memberService.registerMember("test", 1);

        //when //then
//        Assertions.assertThrows( IllegalArgumentException.class, () -> {
//            memberService.findOneMember(2L);
//        });
    }


    @DisplayName("")
    @Test
    void test(){
        System.out.println("test2");
    }

    @BeforeEach
    void beforeEach(){
        System.out.println("====before each===");
    }

    @AfterEach
    void afterEach(){
        System.out.println("====after each====");
    }


}