package com.example.dormitory2.domain.model;

public class DiscountPercentPolicy {
    public int calculate(int price){
        return (int)(price * 0.5);
    }
}
