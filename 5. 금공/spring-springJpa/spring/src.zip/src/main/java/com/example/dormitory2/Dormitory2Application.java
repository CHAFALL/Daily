package com.example.dormitory2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dormitory2Application {

    public static void main(String[] args) {
        SpringApplication.run(Dormitory2Application.class, args);
    }

}
