package com.example.dormitory2.domain.model;

public class Book {
    private Long id;
    private Member member;
    private DormType type;
    private Integer price;

    public Book(Member member, int price, DormType type) {
        this.member = member;
        this.price = price;
        this.type = type;
    }

    public void setId(Long newId) {
        this.id = newId;
    }

    public Long getId(){
        return id;
    }

    public Member getMember(){
        return member;
    }

    public int getPrice(){
        return price;
    }
}
