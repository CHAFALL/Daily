package com.example.jpastudy.domain.repository;

import com.example.jpastudy.domain.model.Member;

public interface MemberRepository {
    Member save(Member member);
}
