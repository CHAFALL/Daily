package com.example.jpastudy.service;

import com.example.jpastudy.domain.model.Member;
import com.example.jpastudy.domain.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@RequiredArgsConstructor
@Service
@Transactional
public class MemberService {
    private final MemberRepository memberRepository;

    public void registerMember(String name, int age){
        Member member = new Member(name, age);
        memberRepository.save(member);
    }
}
