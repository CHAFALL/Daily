package com.example.jpastudy.controller;

import com.example.jpastudy.service.MemberService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/members")
public class MemberController {
    private final MemberService memberService;

    @PostMapping
    public void registerMember(@RequestBody MemberRequest request){
        memberService.registerMember(request.getName(), request.getAge());
    }

    @Data
    public static class MemberRequest{
        private String name;
        private int age;
    }
}
