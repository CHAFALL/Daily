package com.example.jpastudy.domain.model;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Product {
    @Id @GeneratedValue
    private Long id;
}
