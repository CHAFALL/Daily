package com.example.jpastudy.domain.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class Orders {
    @Id @GeneratedValue
    private Long id;
    @ManyToOne
    private Member member;
    @ManyToOne
    private Product product;
    private LocalDateTime boughtAt;
    private Integer price;
}
