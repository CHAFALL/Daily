package com.example.jpastudy.domain.model;

public enum MemberType {
    SEMI_USER, ADMIN, USER;
}
