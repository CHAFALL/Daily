package com.example.jpastudy.domain.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Entity
@NoArgsConstructor
@Getter
public class Member {
    @Id @GeneratedValue
    private Long id;

    @Column(nullable = false)
    private String name;

    @Setter
    private Integer age;

    @Setter
    @Enumerated(EnumType.STRING)
    private MemberType type;

    @ManyToOne
    private Team team;

//    //Locker FK
    @OneToOne(mappedBy = "member")
    private Locker locker;

    public void setTeam(Team team){
        this.team = team;
    }

    public Member(String name, Integer age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Member member = (Member) o;
        return Objects.equals(id, member.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
