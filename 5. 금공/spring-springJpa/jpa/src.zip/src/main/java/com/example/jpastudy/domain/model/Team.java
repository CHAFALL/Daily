package com.example.jpastudy.domain.model;

import jakarta.persistence.*;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Entity
public class Team {
    @Id @GeneratedValue
    private Long id;
    @OneToMany(mappedBy = "team")
    private List<Member> members = new ArrayList<>();

}
