package com.example.jpastudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaStudyApplicationTests {

    @Test
    void contextLoads() {
    }

}
