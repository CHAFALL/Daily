package com.example.jpastudy;

import com.example.jpastudy.domain.model.Member;
import com.example.jpastudy.domain.model.MemberType;
import com.example.jpastudy.domain.model.Team;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.TransactionManager;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@Transactional
@Rollback(false)
public class Main {
    @Autowired
    private EntityManager em;
    @Autowired
    private TransactionManager tm;

    @Test
    public void test(){
//        MemberUser member = em.find(MemberUser.class, 252L);
//        em.detach(member);
////        member.setAge(20);
//
//        MemberUser mergedMember = em.merge(member);
//
//        mergedMember.setAge(200);
//        member.setAge(500);
//
//        System.out.println("em.merge(member) = " + em.contains(member));
//        System.out.println("em.merge(megredMember) = " + em.contains(mergedMember));



//        Member member2 = em.find(Member.class, 202L);
//
////        System.out.println("member1 = " + member.getId());
////        System.out.println("member2 = " + member2.getId());
//        System.out.println(member.equals(member2));
//        System.out.println(member==member2);

//        em.remove(member);

        Member member = new Member("lee", 30);
        em.persist(member);

        Team team = new Team();

//        team.addMember(member);
//        member.setTeam(team);
        member.setTeam(team);
        em.persist(team);
//        member.setTeam(team);


//        Member member = em.find(Member.class, 1L);
//        System.out.println("member.getType() = " + member.getType());

//        em.find(Member.class, 202L);
    }
}
