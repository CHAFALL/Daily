<template>
  <div class="container">
    <page-title title="고객목록" />
    <h3 style="border-left: 5px solid red; padding-left: 3px; text-align: left">
      고객목록
    </h3>
    <button class="btn btn-danger">클릭</button>
  </div>
</template>
<script>
// import PageTitle from '@/components/fragments/PageTitle.vue'
export default {
  // components: { PageTitle },
  data() {
    return {
      sampleData: ''
    }
  },
  setup() {},
  created() {},
  mounted() {},
  unmounted() {},
  methods: {}
}
</script>
