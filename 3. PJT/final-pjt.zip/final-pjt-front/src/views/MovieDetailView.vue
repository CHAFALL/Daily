<template>
  <div>
    <h1 class="navbar">Movie Detail</h1>
    <MovieDetail />
  </div>
</template>

<script setup>

import MovieDetail from '@/components/Movie/MovieDetail.vue'

</script>

<style scoped>

</style>