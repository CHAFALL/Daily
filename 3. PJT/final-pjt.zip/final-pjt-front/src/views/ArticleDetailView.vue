<template>
  <div>
    <ArticleDetail/>
  </div>
</template>

<script setup>

import ArticleDetail from '@/components/Article/ArticleDetail.vue'

</script>

<style scoped>

</style>